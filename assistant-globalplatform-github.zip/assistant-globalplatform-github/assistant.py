import requests
from gtts import gTTS
import pygame
import os
import speech_recognition as sr
import tkinter as tk

def update_content(content):
    payload["messages"][0]["content"] = content

def send_request(content):
    update_content(content)
    response = requests.post(url, json=payload, headers=headers)
    try:
        assistant_response = response.json()['choices'][0]['message']['content']
        response_text.insert(tk.END, assistant_response + "\n")
        speak_response(assistant_response)
    except (KeyError, IndexError):
        response_text.insert(tk.END, "No assistant response found in the response\n")

def speak_response(response_text):
    tts = gTTS(text=response_text, lang='en')
    tts.save("response.mp3")
    pygame.mixer.init()
    pygame.mixer.music.load("response.mp3")
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)
    os.remove("response.mp3")  # Delete the MP3 file after it has been played

def listen_microphone():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        response_text.insert(tk.END, "Listening...\n")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
    try:
        user_input = recognizer.recognize_google(audio)
        response_text.insert(tk.END, "You said: " + user_input + "\n")
        send_request(user_input)
    except sr.UnknownValueError:
        response_text.insert(tk.END, "Sorry, I couldn't understand what you said.\n")
    except sr.RequestError as e:
        response_text.insert(tk.END, "Could not request results from Google Speech Recognition service; {0}\n".format(e))

url = "https://chat-gpt26.p.rapidapi.com/"

payload = {
    "model": "gpt-3.5-turbo",
    "messages": [
        {
            "role": "user",
            "content": ""
        }
    ]
}

headers = {
    "content-type": "application/json",
    "X-RapidAPI-Key": "56eaf3b87fmsh8f2558680dd8234p1eec7djsn36784d95d0d9",
    "X-RapidAPI-Host": "chat-gpt26.p.rapidapi.com"
}

def start_listening():
    listen_microphone()

def submit_text():
    user_input = text_entry.get()
    if user_input == placeholder or user_input == "":
        return
    response_text.insert(tk.END, "You said: " + user_input + "\n")
    send_request(user_input)
    text_entry.delete(0, tk.END)
    text_entry.insert(0, placeholder)
    text_entry.config(fg='grey')

def on_entry_click(event):
    if text_entry.get() == placeholder:
        text_entry.delete(0, tk.END)
        text_entry.config(fg='black')

def on_focusout(event):
    if text_entry.get() == '':
        text_entry.insert(0, placeholder)
        text_entry.config(fg='grey')

def on_key_release(event):
    if text_entry.get() == '':
        text_entry.config(fg='grey')
        text_entry.insert(0, placeholder)
    elif text_entry.get() == placeholder:
        text_entry.delete(0, tk.END)
        text_entry.config(fg='black')
    else:
        text_entry.config(fg='black')

# Create the main window
root = tk.Tk()
root.title("Voice Assistant")

# Load the image
image_path = "assistant.png"  # Path to the uploaded image
image = tk.PhotoImage(file=image_path)

# Create a label to display the image
image_label = tk.Label(root, image=image)
image_label.pack()

# Placeholder text
placeholder = "enter text input here"

# Create an entry widget for text input
text_entry = tk.Entry(root, width=50, fg='grey')
text_entry.insert(0, placeholder)
text_entry.bind('<FocusIn>', on_entry_click)
text_entry.bind('<FocusOut>', on_focusout)
text_entry.bind('<KeyRelease>', on_key_release)
text_entry.pack()

# Create a button to submit text
submit_button = tk.Button(root, text="Submit", command=submit_text)
submit_button.pack()

# Create a text box to display responses
response_text = tk.Text(root, height=20, width=50)
response_text.pack()

# Create a button to trigger speech input
listen_button = tk.Button(root, text="Listen", command=start_listening)
listen_button.pack()

root.mainloop()

